{
    "code": "0",
    "message": "",
    "count": 100,
    "data": [{
        "id": 2012,
        "name":"朱培栋",
        "company":"gadline+",
        "department":"建筑",
        "keyInfo": "gadline+--建筑"
    }, {
        "id": 705,
        "name":"孟凡浩g+",
        "company":"gadline+",
        "department":"建筑",
        "keyInfo": "gadline+--建筑"
    }, {
        "id": 6,
        "name":"朱秋龙",
        "company":"重庆",
        "department":"建筑",
        "keyInfo": "重庆"
    }, {
        "id": 9,
        "name":"徐亮",
        "company":"浙江",
        "department":"建筑一部",
        "keyInfo": "AT13"
    }, {
        "id": 34,
        "name":"王晓夏",
        "company":"浙江",
        "department":"建筑二部",
        "keyInfo": "AT21"
    }, {
        "id": 21,
        "name":"李伟",
        "company":"浙江",
        "department":"建筑二部",
        "keyInfo": "AT23"
    }, {
        "id": 58,
        "name":"吴轩研创",
        "company":"集团 ",
        "department":"研创中心",
        "keyInfo": "集团--研创中心"
    }, {
        "id": 33,
        "name":"任宏",
        "company":"浙江",
        "department":"建筑一部",
        "keyInfo": "AT12"
    }, {
        "id": 14,
        "name":"方巽科",
        "company":"浙江",
        "department":"结构",
        "keyInfo": "浙江"
    }, {
        "id": 58,
        "name":"吴轩研创",
        "company":"集团 ",
        "department":"研创中心",
        "keyInfo": "集团--研创中心"
    }, {
        "id": 33,
        "name":"任宏",
        "company":"浙江",
        "department":"建筑一部",
        "keyInfo": "AT12"
    }, {
        "id": 14,
        "name":"方巽科",
        "company":"浙江",
        "department":"结构",
        "keyInfo": "浙江"
    }]
}
{
  "code": 0
  ,"msg": ""
  ,"count": "100"
  ,"data": [{
    "id": 111
    ,"title": "线上系统填写说明ver1.0-补充4-WB等外援/外包子项"
    ,"publisher": "管理员"
    ,"channel": "填写说明"
    ,"href": "http://fly.layui.com/jie/15697/"
    ,"pubDate": "2018-07-31"
  },{
    "id": 222
    ,"title": "线上系统填写说明ver1.0-补充6-月报中施工图设计时间补充说明"
    ,"publisher": "管理员"
    ,"channel": "填写说明"
    ,"href": "http://fly.layui.com/jie/16622/"
    ,"pubDate": "2018-07-25"
  },{
    "id": 333
    ,"title": "线上系统填写说明ver1.0-补充5-周报各性质款项信息要素说明"
    ,"publisher": "管理员"
    ,"channel": "填写说明"
    ,"href": "http://fly.layui.com/jie/16651/"
    ,"pubDate": "2018-07-19"
  },{
    "id": 333
    ,"title": "线上系统填写说明ver1.0-补充3-设计起止日期补充说明"
    ,"publisher": "管理员"
    ,"channel": "填写说明"
    ,"href": "http://fly.layui.com/jie/9352/"
    ,"pubDate": "2018-07-05"
  },{
    "id": 333
    ,"title": "线上系统填写说明ver1.0-补充2"
    ,"publisher": "管理员"
    ,"channel": "填写说明"
    ,"href": "http://fly.layui.com/jie/9352/"
    ,"pubDate": "2018-06-28"
  },{
    "id": 333
    ,"title": "线上系统填写说明ver1.0-补充1"
    ,"publisher": "管理员"
    ,"channel": "填写说明"
    ,"href": "http://fly.layui.com/jie/9352/"
    ,"pubDate": "2018-05-30"
  },{
    "id": 333
    ,"title": "线上系统填写说明ver1.0-补充1"
    ,"publisher": "管理员"
    ,"channel": "填写说明"
    ,"href": "http://fly.layui.com/jie/9352/"
    ,"pubDate": "2018-05-30"
  },{
    "id": 333
    ,"title": "线上系统填写说明ver1.0"
    ,"publisher": "管理员"
    ,"channel": "填写说明"
    ,"href": "http://fly.layui.com/jie/9352/"
    ,"pubDate": "2018-05-30"
  }]
}
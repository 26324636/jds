{
  "code": 0
  ,"msg": ""
  ,"count": "100"
  ,"data": [{
    "title": "月报信息-技术中心查询模块上线"
    ,"publisher": "管理员"
    ,"pubDate": "2018-09-10"
  },{
    "title": "人员业绩查询模块试运行"
    ,"publisher": "管理员"
    ,"pubDate": "2018-08-23"
  },{
    "title": "外包支付模块试运行"
    ,"publisher": "管理员"
    ,"pubDate": "2018-08-23"
  },{
    "title": "线上系统填写说明ver 1.0"
    ,"publisher": "管理员"
    ,"pubDate": "2018-05-02"
  },{
    "title": "周报系统试运行"
    ,"publisher": "管理员"
    ,"pubDate": "2018-04-19"
  },{
    "title": "系统更新1 增加消息模块等"
    ,"publisher": "管理员"
    ,"pubDate": "2018-04-11"
  },{
    "title": "测试版本月报正式启用"
    ,"publisher": "管理员"
    ,"pubDate": "2018-04-11"
  },{
    "title": "新增测试版本月报"
    ,"publisher": "管理员"
    ,"pubDate": "2018-01-05"
  },{
    "title": "产值表填写入口修改，填写界面和权限修改，增加产值表填写状态"
    ,"publisher": "管理员"
    ,"pubDate": "2017-07-31"
  },{
    "title": "产值表和面积表功能代码更新"
    ,"publisher": "管理员"
    ,"pubDate": "2017-06-23"
  }]
}